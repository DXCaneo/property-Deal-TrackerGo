export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head />
      <body className="bg-gray-50 text-gray-900 font-sans p-6">{children}</body>
    </html>
  );
}