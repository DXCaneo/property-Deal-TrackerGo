export default function PropertyTrackerApp() {
  return <div className="p-4 text-xl font-bold">Property Tracker App</div>;
}