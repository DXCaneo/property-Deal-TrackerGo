export default function Page() {
  return (
    <div className="p-6 text-xl font-semibold text-center">
      ✅ Property Deal Tracker App is deployed successfully!
    </div>
  );
}